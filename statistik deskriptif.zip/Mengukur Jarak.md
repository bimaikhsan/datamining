## Pengertian

Salah satu tantangan dalam era ini dengan datatabase yang memiliki banyak tipe data. Mengukur jarak adalah komponen utama dalam algoritma clustering berbasis jarak. Alogritma seperit Algoritma Partisioning misal K-Mean, K-medoidm dan fuzzy c-mean dan rough clustering bergantung pada jarak untuk melakukan pengelompokkan.

## Mengukur Jarak Menggunakan Minkowski Distance

Langkah-langkah mengukur jarak kali ini saya menggunakan Minkowski Distance . Minkowski Distance adalah matrik dalam ruang vektor normed yang dapat dianggap sebagai generalisasi dari Euclidean Distance dan Manhattan Distance.
$$
d _ { \operatorname { min } } = ( \ sum _ { i = 1 } ^ { n } | x _ { i } - y _ { i } | ^ { m }  ) ^ { \frac { 1 } { m } } , m \geq 1
$$

diman mm adalah bilangan riel positif dan xixi dan $ y_i$ adalah dua vektor dalam runang dimensi nn Implementasi ukuran jarak Minkowski pada model clustering data atribut dilakukan normalisasi untuk menghindari dominasi dari atribut yang memiliki skala data besar.

Langkah-Langkah Mengukur jarak:

1. sebelumnya kita ambil data dari website [https://archive.ics.uci.edu/ml/datasets/wholesale+customers](https://archive.ics.uci.edu/ml/datasets/wholesale+customers)
2. Download datanya dan kita jalankan python , tulis script seperti di bawah ini digunakan untuk mengambil data 4 baris :

```python
import pandas as pd
from scipy import stats
df = pd.read_csv('Wholesale customers data.csv',nrows=4,sep=';')
df
```



3. Hasil dari script di atas:

   <table border="1" class="dataframe">
     <thead>
       <tr style="text-align: right;">
         <th></th>
         <th>Channel</th>
         <th>Region</th>
         <th>Fresh</th>
         <th>Milk</th>
         <th>Grocery</th>
         <th>Frozen</th>
         <th>Detergents_Paper</th>
         <th>Delicassen</th>
       </tr>
     </thead>
     <tbody>
       <tr>
         <th>0</th>
         <td>2</td>
         <td>3</td>
         <td>12669</td>
         <td>9656</td>
         <td>7561</td>
         <td>214</td>
         <td>2674</td>
         <td>1338</td>
       </tr>
       <tr>
         <th>1</th>
         <td>2</td>
         <td>3</td>
         <td>7057</td>
         <td>9810</td>
         <td>9568</td>
         <td>1762</td>
         <td>3293</td>
         <td>1776</td>
       </tr>
       <tr>
         <th>2</th>
         <td>2</td>
         <td>3</td>
         <td>6353</td>
         <td>8808</td>
         <td>7684</td>
         <td>2405</td>
         <td>3516</td>
         <td>7844</td>
       </tr>
       <tr>
         <th>3</th>
         <td>1</td>
         <td>3</td>
         <td>13265</td>
         <td>1196</td>
         <td>4221</td>
         <td>6404</td>
         <td>507</td>
         <td>1788</td>
       </tr>
     </tbody>
   </table>

4. Menghitung Jarak antar data:

   ```python
   import scipy.spatial.distance as minko
   import itertools
   
   def minkowski (x,y,data):
       return sum(x)+sum(y)
   dfvalues = df.values.tolist()
   data  = [
       [x[0],x[1],minko.minkowski(dfvalues[x[0]], dfvalues[x[1]], 1)
        ,minko.minkowski(dfvalues[x[0]], dfvalues[x[1]], 2)] 
       for x in itertools.combinations(range(4),2)
   ]
   columns = ['x','y', 'Minkowski (m-1)', 'Minkowski (m-2)']
   pd.DataFrame(data, coluns=columns)
   ```

5. Hasil dari script di atas:

   <table border="1" class="dataframe">
     <thead>
       <tr style="text-align: right;">
         <th></th>
         <th>x</th>
         <th>y</th>
         <th>Minkowski (m-1)</th>
         <th>Minkowski (m-2)</th>
       </tr>
     </thead>
     <tbody>
       <tr>
         <th>0</th>
         <td>0</td>
         <td>1</td>
         <td>10378.0</td>
         <td>6206.256360</td>
       </tr>
       <tr>
         <th>1</th>
         <td>0</td>
         <td>2</td>
         <td>16826.0</td>
         <td>9405.507429</td>
       </tr>
       <tr>
         <th>2</th>
         <td>0</td>
         <td>3</td>
         <td>21204.0</td>
         <td>11238.189623</td>
       </tr>
       <tr>
         <th>3</th>
         <td>1</td>
         <td>2</td>
         <td>10524.0</td>
         <td>6506.372107</td>
       </tr>
       <tr>
         <th>4</th>
         <td>1</td>
         <td>3</td>
         <td>27610.0</td>
         <td>13062.954260</td>
       </tr>
       <tr>
         <th>5</th>
         <td>2</td>
         <td>3</td>
         <td>31052.0</td>
         <td>13395.218401</td>
       </tr>
     </tbody>
   </table>

6. Langkah di bawah ini Mengukur Jarak Antara Numerick

   ```python
   numerical=[0,3]
   categorical=[1,2,6,7]
   binary=[4,5,8]
   ordinal=[1,2]
   ```

   ```on
   def chordDist(v1,v2,jnis):
       jmlh=0
       normv1=0
       normv2=0
       for x in range (len(jnis)):
           normv1=normv1+(int(df.values.tolist()[v1][jnis[x]])**2)
           normv2=normv2+(int(df.values.tolist()[v1][jnis[x]])**2)
           jmlh=jmlh+(int(df.values.tolist()[v1][jnis[x]])*int(df.values.tolist()[v2][jnis[x]]))
       return ((2-(2*jmlh/(normv1*normv2)))**0.5)
   ```

7. Hasil dari script di atas:

   <table>
   <tbody>
   <tr><td>x</td><td>y</td><td>Jarak</td><td>Numeric</td><td>Ordinal</td><td>Categorical</td><td>Binary</td></tr>
   <tr><td>0</td><td>2</td><td>0    </td><td>1.41   </td><td>0      </td><td>0          </td><td>0     </td></tr>
   <tr><td>0</td><td>3</td><td>0    </td><td>1.41   </td><td>0      </td><td>0          </td><td>0     </td></tr>
   <tr><td>1</td><td>2</td><td>0    </td><td>1.41   </td><td>0      </td><td>0          </td><td>0     </td></tr>
   <tr><td>1</td><td>3</td><td>0    </td><td>1.41   </td><td>0      </td><td>0          </td><td>0     </td></tr>
   <tr><td>2</td><td>3</td><td>0    </td><td>1.41   </td><td>0      </td><td>0          </td><td>0     </td></tr>
   </tbody>
   </table>

  <script type="text/x-mathjax-config">
MathJax.Hub.Config({
  tex2jax: {inlineMath: [['$$','$$']]}
});
</script>
  <script type="text/javascript" async
  src="https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-MML-AM_CHTML">
</script>