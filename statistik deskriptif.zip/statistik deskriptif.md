## Pengertian

> <div style="text-align:justify;"><b>Statistika deskriptif</b> adalah metode-metode yang berkaitan dengan pengumpulan dan penyajian suatu gugus data sehingga memberikan informasi yang berguna. Pengklasifikasian menjadi statistika deskriptif dan statistika inferensi dilakukan berdasarkan aktivitas yang dilakukan.</div>

<div style="text-align:justify;">Statistika deskriptif hanya memberikan informasi mengenai data yang 
dipunyai dan sama sekali tidak menarik inferensia atau kesimpulan apapun
tentang gugus induknya yang lebih besar. Contoh statistika deskriptif yang sering muncul adalah, tabel, diagram, grafik, dan besaran-besaran lain di majalah dan koran-koran Dengan Statistika deskriptif, kumpulan data yang diperoleh akan tersaji 
dengan ringkas dan rapi serta dapat memberikan informasi inti dari 
kumpulan data yang ada. Informasi yang dapat diperoleh dari statistika 
deskriptif ini antara lain: ukuran pemusatan data, ukuran penyebaran data serta kecenderungan suatu gugus data.</div> 

## Tipe Statistik Deskriptif

### Mean (rata-rata)

<div style="text-align:justify">Mean adalah *nilai rata-rata* dari beberapa buah data. Nilai mean dapat ditentukan dengan membagi jumlah data dengan banyaknya data.</div>
<div style="text-align:justify">Mean (rata-rata) merupakan suatu ukuran pemusatan data. Mean suatu data juga merupakan statistik karena mampu menggambarkan bahwa data tersebut berada pada kisaran mean data tersebut. Mean tidak dapat digunakan sebagai ukuran pemusatan untuk jenis data nominal dan ordinal.</div>
<div style="text-align:justify">Berdasarkan definisi dari mean adalah jumlah seluruh data dibagi dengan banyaknya data. Dengan kata lain jika kita memiliki N data sebagai berikut maka mean data tersebut dapat kita tuliskan sebagai berikut :</div>
$$
\bar x ={\sum \limits_{i=1}^{n} x_i \over N} = {x_1 + x_2 + x_3 + ... + x_n \over N}
$$
Dimana:
x = data ke n
x bar = x rata-rata = nilai rata-rata sampel
n = banyaknya data

### Median

<div style="text-align:justify">Median menentukan letak tengah data setelah data disusun menurut urutan  nilainya. Bisa juga *nilai tengah dari data-data yang terurut. Simbol  untuk median adalah Me.  Dengan median Me, maka 50% dari banyak data  nilainya paling tinggi sama dengan Me, dan 50% dari banyak data nilainya  paling rendah sama dengan Me. Dalam  mencari median, dibedakan  untuk  banyak data ganjil  dan banyak data genap.  Untuk  banyak data ganjil,  setelah data disusun menurut nilainya, maka median Me adalah data yang  terletak tepat di tengah. Median bisa dihitung menggunakan rumus sebagai  berikut:</div>
$$
Me=Q_2 =\left( \begin{matrix}
  ^xn+1 \over 2
\end{matrix} \right), jika n ganjil
$$

$$
Me=Q_2 =\left( \begin{matrix}
  {^xn \over 2 } {^xn+1\over 2} \over 2
\end{matrix} \right), jika n genap
$$

### Modus

<div style="text-align:justify;">Modus adalah nilai yang sering muncul. Jika kita tertarik pada data frekuensi, jumlah dari suatu nilai dari kumpulan data, maka kita menggunakan modus. Modus sangat baik bila digunakan untuk data yang memiliki sekala kategorik yaitu nominal atau ordinal. Modus bisa dihitung menggunakan rumus sebagai  berikut:</div>
$$
M_o = L + i{b_i \over b_1 + b_2}
$$

Dimana: 

Mo = Modus
L = Tepi bawah kelas yang memiliki frekuensi tertinggi (kelas modus) i = Interval kelas
b1 = Frekuensi kelas modus dikurangi frekuensi kelas interval terdekat sebelumnya
b2 = frekuensi kelas modus dikurangi frekuensi kelas interval terdekat sesudahnya

### Standar Deviasi

<div style="text-align:justify;">Standar Deviasi dan Varians Salah satu teknik statistik yg digunakan  untuk menjelaskan homogenitas kelompok. Varians merupakan jumlah kuadrat  semua deviasi nilai-nilai individual terhadap rata-rata kelompok. Sedangkan  akar dari varians disebut dengan standar deviasi atau simpangan baku.</div>
<div style="text-align:justify;">Standar Deviasi dan Varians Simpangan baku merupakan variasi sebaran  data. Semakin kecil nilai sebarannya berarti variasi nilai data makin  sama Jika sebarannya bernilai 0, maka nilai semua datanya adalah sama.  Semakin besar nilai sebarannya berarti data semakin bervariasi. Standar Deviasi bisa didapat menggunakan rumus sebagai  berikut:</div>
$$
\sigma = {\sqrt{ \sum \limits_{i=1}^{n} {(x_1-\bar x)^2 } \over n }}
$$

Dimana :

x = data ke n
x bar = x rata-rata = nilai rata-rata sampel
n = banyaknya data

### Varians

<div style="text-align:justify">Varians merupakan rata-rata dari selisih kuadrat tersebut merupakan suatu ukuran penyimpangan dari observasi. Simbol varians pada ukuran populasi sigma kuarat dan pada ukuran sample S2. Akar dari varians dinamakan standar deviasi atau simpangan baku. Varians bisa didapat menggunakan rumus sebagai  berikut:</div>
$$
S^2 = {\sqrt{ \sum \limits_{i=1}^{n} {(x_1-\bar x)^2 } \over n-1 }}
$$

### Skewness

<div style="text-align:justify">Skewness (<i>kemencengan</i>) adalah derajat ketidaksimetrisan suatu distribusi. Jika kurva frekuensi suatu distribusi memiliki ekor yang lebih memanjang ke kanan (dilihat dari meannya) maka dikatakan menceng kanan (positif) dan jika sebaliknya maka menceng kiri (negatif). Secara perhitungan, skewness adalah momen ketiga terhadap mean. Distribusi normal (dan distribusi simetris lainnya, misalnya distribusi t atau Cauchy) memiliki skewness 0 (nol). Skewness bisa dihitung menggunakan rumus sebagai  berikut:</div>
$$
Skewness (S) = {{1 \over T\sigma^3} \sum \limits_{i=1}^{n}(r_2 - \mu)^3}
$$

### Quartile

<div style="text-align:justify;">Quartile adalah nilai-nilai yang membagi segugus pengamatan menjadi empat bagian sama besar. Nilai-nilai itu, yang dilambangkan dengan Q1, Q2, dan Q3, mempunyai sifat bahwa 25% data jatuh dibawah Q1, 50% data jatuh dibawah Q2, dan 75% data jatuh dibawah Q3. Quartile bisa dihitung menggunakan rumus sebagai  berikut:</div>
$$
Q_1 = {x_{{1\over4}(n+1)}}
$$

$$
Q_2 = {x_{{1\over2}(n+1)}}
$$

$$
Q_3 = {x_{{3\over4}(n+1)}}
$$



## Penerapan statistik deskriptif menggunakan python

### Alat dan Bahan

Pada penerapan ini saya menggunakan 500 data random yang disimpan dalam bentuk .csv dan untuk mempermudah dalam penerapan tersebut, perlu disiapkan library python yang dapat didownload secara gratis.

dalam kasus ini library python yang digunakan adalah sebagai berikut:

1. pandas, digunakan untuk data manajemen dan data analysis.
2. scipy, berisi kumpulan algoritme dan fungsi matematika.

### Pertama

pada langkah ini kita memasukkan library yang telah disiapkan sebelumya

```python
import pandas as pd
from scipy import stats
```

### Kedua

dan selanjutnya memuat data csv yang telah disiapkan

```python
df = pd.read_csv('Data.csv',sep=';')
```

### Ketiga

<div style="text-align:justify;">kemudian membuat data penyimpanan (<i>dictionary</i>) yang menampung nilai yang akan ditampilkan. selanjutnya mengambil data dari beberapa kolom pada csv dengan cara diiterasi serta menghitungnya dengan berbagai metode yang telah disiapkan oleh pandas itu sendiri.  kemudian hasil tersebut di disimpan pada penyimpanan tadi</div>
```python
data = {"Stats" : ['Min','Max','Mean','Standard Deviasi','Variasi','Skewnes',
                   'Quartile 1','Quartile 2', 'Quartile 3', 'Median','Modus']}
for i in df.columns:
    data[i] = [df[i].min(), df[i].max(), df[i].mean(),
                round(df[i].std(), 2),round(df[i].var(), 2),
                round(df[i].skew(), 2), df[i].quantile(0.25),
                df[i].quantile(0.5), df[i].quantile(0.75),
                df[i].median(), stats.mode(df[i]).mode[0]]
    
```

### Keempat

terakhir adalah menvisualisasikan hasil tersebut dalam bentuk dataframe

```python
tes = pd.DataFrame(data)
tes.style.hide_index()
```



<table border='1'>
    <thead>
        <tr>
            <th>stats</th>
            <th>data 1</th>
            <th>data 2</th>
            <th>data 3</th>
            <th>data 4</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Min</td>
            <td>81</td>
            <td>81</td>
            <td>80</td>
            <td>80</td>
        </tr>
        <tr>
            <td>Max</td>
            <td>160</td>
            <td>160</td>
            <td>160</td>
            <td>160</td>
        </tr>
        <tr>
            <td>Mean</td>
            <td>120.26</td>
            <td>124.67</td>
            <td>122</td>
            <td>118.02</td>
        </tr>
        <tr>
            <td>Standard Deviasi</td>
            <td>24.78</td>
            <td>22.47</td>
            <td>24.55</td>
            <td>22.67</td>
        </tr>
        <tr>
            <td>Variasi</td>
            <td>613.89</td>
            <td>504.89</td>
            <td>602.57</td>
            <td>513.72</td>
        </tr>
        <tr>
            <td>Skewnes</td>
            <td>0.11</td>
            <td>-0.22</td>
            <td>-0.07</td>
            <td>0.12</td>
        </tr>
        <tr>
            <td>Quantile 1</td>
            <td>97</td>
            <td>106.75</td>
            <td>101.75</td>
            <td>99.5</td>
        </tr>
        <tr>
            <td>Quantile 2</td>
            <td>117.5</td>
            <td>126.5</td>
            <td>123.5</td>
            <td>118</td>    
        </tr>
        <tr>
            <td>Quantile 3</td>
            <td>143.25</td>
            <td>143.25</td>
            <td>144</td>
            <td>137.25</td>
        </tr>
        <tr>
            <td>Median</td>
            <td>117.5</td>
            <td>126.5</td>
            <td>123.5</td>
            <td>118</td>
        </tr>
        <tr>
            <td>Modus</td>
            <td>84</td>
            <td>131</td>
            <td>89</td>
            <td>124</td>
        </tr>
    </tbody>
</table>

## Source

Seluruh file percobaan ada pada link berikut : <a href="https://github.com/bimaikhsan/Penambangan_data" target='_blanks'>disini</a>

<div style="font-size:25px">Referensi</div>
> <div style="font-size:14px;"">
> <ol>
> <li>http://blog.ub.ac.id/adiarsa/2012/03/14/mean-median-modus-dan-standar-deviasi/</li>
> <li>http://statutorial.blogspot.com/2008/01/skewness-dan-kurtosis.html</li>
> <li>https://www.rumusstatistik.com/2013/07/varian-dan-standar-deviasi-simpangan.html</li>
> <li>https://www.rumusstatistik.com/2016/12/membuat-rumus-matematika-dengan-latex.html</li>
> <li>https://englishccit.wordpress.com/2012/03/27/pengertian-statistik-deskriptif/#more-1194</li>
> </ol>
> </div>

  <script type="text/x-mathjax-config">
MathJax.Hub.Config({
  tex2jax: {inlineMath: [['$$','$$']]}
});
</script>
  <script type="text/javascript" async
  src="https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-MML-AM_CHTML">
</script>

