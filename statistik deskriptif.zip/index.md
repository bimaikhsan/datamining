# Selamat Datang Di Halaman Tugas Penambangan Data

Nama : Bima Zainudin Ikhsan

Nim : 180411100102

Kelas : Penambangan Data-5B

Jurusan : Teknik Informatika

Angkatan : 2018

Perguruan Tinggi : Universitas Trunojoyo Madura