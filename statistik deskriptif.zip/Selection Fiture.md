# Seleksi Fitur



Seleksi fitur adalah teknik untuk memilih fitur penting dan relevan terhadap data dan mengurangi fitur yang tidak relevan. Seleksi fitur bertujuan untuk memilih fitur terbaik dari suatu kumpulan data fitur. Seleksi fitur bertujuan untuk memilih fitur terbaik dari suatu kumpulan data fitur. Tujuan dari penelitian ini adalah menerapkan metode Information Gain dalam sistem seleksi fitur untuk Permasalahan cuaca . Metode Information Gain adalah metode yang menggunakan teknik scoring untuk pembobotan sebuah fitur dengan menggunakan maksimal entropy. Fitur yang dipilih adalah fitur dengan nilai Information Gain yang lebih besar atau sama dengan nilai threshold tertentu. 

contoh data permasalahan cuaca 

```python
from pandas import *
from IPython.display import HTML, display
from tabulate import tabulate
from math import log
from sklearn.feature_selection import mutual_info_classif

def table(df): 
    display(HTML(tabulate(df, tablefmt='html', headers='keys', showindex=False)))
df = read_csv('featureselection.csv',usecols = [0,1,2,3,4], sep=';')
table(df)
```

<table>
<thead>
<tr><th>outlook  </th><th>temperature  </th><th>humidity  </th><th>windy  </th><th>play  </th></tr>
</thead>
<tbody>
<tr><td>sunny    </td><td>hot          </td><td>high      </td><td>False  </td><td>no    </td></tr>
<tr><td>sunny    </td><td>hot          </td><td>high      </td><td>True   </td><td>no    </td></tr>
<tr><td>overcast </td><td>hot          </td><td>high      </td><td>False  </td><td>yes   </td></tr>
<tr><td>rainy    </td><td>mild         </td><td>high      </td><td>False  </td><td>yes   </td></tr>
<tr><td>rainy    </td><td>cool         </td><td>normal    </td><td>False  </td><td>yes   </td></tr>
<tr><td>rainy    </td><td>cool         </td><td>normal    </td><td>True   </td><td>no    </td></tr>
<tr><td>overcast </td><td>cool         </td><td>normal    </td><td>True   </td><td>yes   </td></tr>
<tr><td>sunny    </td><td>mild         </td><td>high      </td><td>False  </td><td>no    </td></tr>
<tr><td>sunny    </td><td>cool         </td><td>normal    </td><td>False  </td><td>yes   </td></tr>
<tr><td>rainy    </td><td>mild         </td><td>normal    </td><td>False  </td><td>yes   </td></tr>
<tr><td>sunny    </td><td>mild         </td><td>normal    </td><td>True   </td><td>yes   </td></tr>
<tr><td>overcast </td><td>mild         </td><td>high      </td><td>True   </td><td>yes   </td></tr>
<tr><td>overcast </td><td>hot          </td><td>normal    </td><td>False  </td><td>yes   </td></tr>
<tr><td>rainy    </td><td>mild         </td><td>high      </td><td>True   </td><td>no    </td></tr>
</tbody>
</table>



## Mencari Entropy 

Untuk menghitung Information gain perlu dihitung dahulu nilai informasi dalam suatu bits dari suatu kumpulan obyek. Cara penghitungan dilakukan dengan menggunakan konsep entropi. Entropi menyatakan impurity suatu kumpulan obyek . Berikut merupakan definisi dari entropi suatu ruang sampel data (S):
$$
E(T) = \sum_{i=1}^n {-P_i\log{P_i}}
$$
dimana :

T =  ruang sampel data yang di gunakaan untuk data pelatihan

Pi = Probability muncul dalam row

```python
def findEntropy(column):
    rawGroups = df.groupby(column)
    targetGroups = [[key, len(data), len(data)/df[column].size] for key,data in rawGroups]
    targetGroups = DataFrame(targetGroups, columns=['value', 'count', 'probability'])
    return sum([-x*log(x,2) for x in targetGroups['probability']]), targetGroups, rawGroups

entropyTarget, groupTargets, _ = findEntropy('play')
table(groupTargets)
print('entropy target =', entropyTarget)
```

### Entropi

<table>
<thead>
<tr><th>value  </th><th style="text-align: right;">  count</th><th style="text-align: right;">  probability</th></tr>
</thead>
<tbody>
<tr><td>no     </td><td style="text-align: right;">      5</td><td style="text-align: right;">     0.357143</td></tr>
<tr><td>yes    </td><td style="text-align: right;">      9</td><td style="text-align: right;">     0.642857</td></tr>
</tbody>
</table>

```python
entropy target = 0.9402859586706309
```

## Gain

Gain adalah sebuah fiktur yang terdapat pada sebuah data , untuk menghitungnya contoh rumusnya :
$$
\operatorname{Gain}(T, X) = \operatorname{Entropy}(T) - \sum_{v\in{T}} \frac{T_{X,v}}{T} E(T_{X,v})
$$
dimana :

Entropy (T) =  nilai entropi total dari atribut keputusan dalam ruang sampel data T

x = fitur

```python
def findGain(column):
    entropyOutlook, groupOutlooks, rawOutlooks = findEntropy(column)
    table(groupOutlooks)
    gain = entropyTarget-sum(len(data)/len(df)*sum(-x/len(data)*log(x/len(data),2) 
                for x in data.groupby('play').size()) for key,data in rawOutlooks)
    print("gain of",column,"is",gain)
    return gain

gains = [[x,findGain(x)] for x in ['outlook','temperature','humidity','windy']]
```

### Outlook

<table>
<thead>
<tr><th>value   </th><th style="text-align: right;">  count</th><th style="text-align: right;">  probability</th></tr>
</thead>
<tbody>
<tr><td>overcast</td><td style="text-align: right;">      4</td><td style="text-align: right;">     0.285714</td></tr>
<tr><td>rainy   </td><td style="text-align: right;">      5</td><td style="text-align: right;">     0.357143</td></tr>
<tr><td>sunny   </td><td style="text-align: right;">      5</td><td style="text-align: right;">     0.357143</td></tr>
</tbody>
</table>

```python
gain of outlook is 0.2467498197744391
```

### Temperature

<table>
<thead>
<tr><th>value  </th><th style="text-align: right;">  count</th><th style="text-align: right;">  probability</th></tr>
</thead>
<tbody>
<tr><td>cool   </td><td style="text-align: right;">      4</td><td style="text-align: right;">     0.285714</td></tr>
<tr><td>hot    </td><td style="text-align: right;">      4</td><td style="text-align: right;">     0.285714</td></tr>
<tr><td>mild   </td><td style="text-align: right;">      6</td><td style="text-align: right;">     0.428571</td></tr>
</tbody>
</table>

```python
gain of temperature is 0.029222565658954647
```

### Humidity

<table>
<thead>
<tr><th>value  </th><th style="text-align: right;">  count</th><th style="text-align: right;">  probability</th></tr>
</thead>
<tbody>
<tr><td>high   </td><td style="text-align: right;">      7</td><td style="text-align: right;">          0.5</td></tr>
<tr><td>normal </td><td style="text-align: right;">      7</td><td style="text-align: right;">          0.5</td></tr>
</tbody>
</table>

```python
gain of humidity is 0.15183550136234136
```

### Windy

<table>
<thead>
<tr><th>value  </th><th style="text-align: right;">  count</th><th style="text-align: right;">  probability</th></tr>
</thead>
<tbody>
<tr><td>False  </td><td style="text-align: right;">      8</td><td style="text-align: right;">     0.571429</td></tr>
<tr><td>True   </td><td style="text-align: right;">      6</td><td style="text-align: right;">     0.428571</td></tr>
</tbody>
</table>

```python
gain of windy is 0.04812703040826927
```

## Skor keseluruhan Gain 

Skor ini sudah di urutkan menurut tingkat tertingi dari sebuat semua Gain, tergantung dari kalian mau mengambil berapa banyak data yang terpenting , bisa 2 atau lebih. 

```python
table(DataFrame(gains, columns=["Feature", "Gain Score"]).sort_values("Gain Score")[::-1])
```

<table>
<thead>
<tr><th>Feature    </th><th style="text-align: right;">  Gain Score</th></tr>
</thead>
<tbody>
<tr><td>outlook    </td><td style="text-align: right;">   0.24675  </td></tr>
<tr><td>humidity   </td><td style="text-align: right;">   0.151836 </td></tr>
<tr><td>windy      </td><td style="text-align: right;">   0.048127 </td></tr>
<tr><td>temperature</td><td style="text-align: right;">   0.0292226</td></tr>
</tbody>
</table>







  <script type="text/x-mathjax-config">
MathJax.Hub.Config({
  tex2jax: {inlineMath: [['$$','$$']]}
});
</script>
  <script type="text/javascript" async
  src="https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-MML-AM_CHTML">
</script>